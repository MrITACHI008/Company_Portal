
// components/Navigation.js
import Link from 'next/link';

const Navigation = () => {
  return (
    <nav className="flex items-center justify-between p-4 bg-white border-b border-orange-500">
    <div className="flex items-center">
      <img src="/logo.png" alt="Itfirm Logo" className="h-12 mr-4" />
      <span className="text-lg font-semibold text-blue-600">IT Solutions & Service</span>
    </div>
    <ul className="flex space-x-4">
      <li><Link legacyBehavior href="/"><a className="text-gray-700 hover:text-gray-900">Home</a></Link></li>
      <li><Link legacyBehavior href="/about"><a className="text-gray-700 hover:text-gray-900">AboutUs</a></Link></li>
      <li><Link legacyBehavior href="/services"><a className="text-gray-700 hover:text-gray-900">Services</a></Link></li>
      <li><Link legacyBehavior href="/careers"><a className="text-gray-700 hover:text-gray-900">Careers</a></Link></li>
      <li><Link legacyBehavior href="/contact"><a className="text-gray-700 hover:text-gray-900">Contact</a></Link></li>
      {/* <li><Link legacyBehavior href="/elements"><a className="text-gray-700 hover:text-gray-900">Elements</a></Link></li> */}
    </ul>
  </nav>
);
};
export default Navigation;

