import React, { useState, useEffect } from 'react';

const Carousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    // Automatically change the slide every 5 seconds
    const intervalId = setInterval(() => {
      setCurrentSlide((prevSlide) => (prevSlide + 1) % 3);
      updateContent();
    }, 100000);

    return () => clearInterval(intervalId);
  }, []);

  const content = [
    'Content for Slide 1',
    'Content for Slide 2',
    'Content for Slide 3',
  ];

  const images = [
    [
      '/images/h6-slider-img1.png', // Center image for Slide 1
      '/images/h6-slider-img2.png', '/images/h6-slider-img3.png', '/images/h6-slider-img4.png', // Corner images for Slide 1
    ],
    [
      '/image5.jpg', // Center image for Slide 2
      '/image6.jpg', '/image7.jpg', '/image8.jpg', // Corner images for Slide 2
    ],
    [
      '/image9.jpg', // Center image for Slide 3
      '/image10.jpg', '/image11.jpg', '/image12.jpg', // Corner images for Slide 3
    ],
  ];

  const handlePrev = () => {
    setCurrentSlide((prevSlide) => (prevSlide - 1 + 3) % 3);
    updateContent();
  };

  const handleNext = () => {
    setCurrentSlide((prevSlide) => (prevSlide + 1) % 3);
    updateContent();
  };

  const updateContent = () => {
    // Update content based on the current slide
    // You can add more sophisticated logic based on your needs
    // For now, we'll just log the current content to the console
    console.log(`Content for Slide ${currentSlide + 1}: ${content[currentSlide]}`);
  };

  return (
    <div className="flex relative h-96" style={{height:"1000px", background:"#fff"}}>
      <div className="w-1/2" style={{width: "400px"}}>
        {/* Left side with content */}
        <div className="p-4">
          <h2>{content[currentSlide]}</h2>
        </div>
      </div>
      <div className="w-1/2 relative h-full" style={{width: "600px"}}>
        {/* Center image */}
        <img
          src={images[currentSlide][0]}
          alt={`Center Image - Slide ${currentSlide + 1}`}
          className="w-auto object-cover absolute top-1/3 right-30 transform -translate-y-1/2"
          style={{width: "auto", height:"450px" }}
        />

        {/* Corner images with hover effect */}
        <div className="absolute top-0 left-0 w-1/3 h-1/3">
          <img
            src={images[currentSlide][1]}
            alt={`Corner Image 1 - Slide ${currentSlide + 1}`}
            className="w-full absolute object-cover transition-opacity duration-300 top-1/4"
            style={{ "zIndex": 2 ,width: "auto", height:"350px"}}
          />
        </div>
        <div className="absolute top-0 right-0 w-1/3 h-1/3">
          <img
            src={images[currentSlide][2]}
            alt={`Corner Image 2 - Slide ${currentSlide + 1}`}
            className="w-full h-full object-cover hover:opacity-70 transition-opacity duration-300"
            style={{ zIndex: 2, "width": "auto", height:"150px" }}
          />
        </div>
        <div className="absolute bottom-0 left-0 w-1/3 h-1/3">
          <img
            src={images[currentSlide][3]}
            alt={`Corner Image 3 - Slide ${currentSlide + 1}`}
            className="w-full h-full object-cover hover:opacity-70 transition-opacity duration-300"
            style={{ zIndex: 2,width: "auto", height:"150px" }}
          />
        </div>
      </div>

      {/* Forward and Backward buttons */}
      <div className="absolute bottom-4 left-4 flex items-center space-x-2">
        <button className="bg-gray-500 p-2 rounded-full text-white" onClick={handlePrev}>
          {'<'}
        </button>
        <button className="bg-gray-500 p-2 rounded-full text-white" onClick={handleNext}>
          {'>'}
        </button>
      </div>
    </div>
  );
};

export default Carousel;
