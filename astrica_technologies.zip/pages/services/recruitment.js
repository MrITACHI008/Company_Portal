import React from 'react'

const recruitment = () => {
  return (
    <div>recruitment</div>
  )
}

export default recruitment
