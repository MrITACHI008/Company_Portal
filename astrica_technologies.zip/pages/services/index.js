import React from 'react'

const services = () => {
  return (
    <div>services</div>
  )
}

export default services;