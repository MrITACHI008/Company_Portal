import React from 'react'

const animation = () => {
  return (
    <div>2d-3d-animation</div>
  )
}

export default animation