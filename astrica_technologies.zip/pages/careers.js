import React from 'react'

const careers = () => {
  return (
    <div>careers</div>
  )
}

export default careers