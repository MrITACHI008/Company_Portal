// pages/index.js
import Header from '../components/Header';
const Home = () => {
  return (
    <div>
      <Header />
      <main>
        {/* Add home page content here */}
        <h1>Welcome to Our Company</h1>
      </main>
    </div>
  );
};

export default Home;
